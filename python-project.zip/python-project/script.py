# pip install -U pymupdf4llm
import pymupdf4llm